//
//  CategoryResViewController.swift
//  POCLandingJa
//
//  Created by CHAIWAT CHANTHASEN on 28/4/2563 BE.
//  Copyright © 2563 CHAIWAT CHANTHASEN. All rights reserved.
//

import UIKit

class CategoryResView: UIView {
  public var cellModel: [CategoryResCellViewModel] = []
}
